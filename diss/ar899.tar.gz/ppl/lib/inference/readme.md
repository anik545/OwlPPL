# Inference

Treat all inference strategies as functions 'a dist -> 'a dist, with the transformation removing conditionals, allowing the dist to be sampled from accurately.
